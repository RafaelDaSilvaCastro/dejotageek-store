package br.com.dejota.dejotaApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DejotaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
