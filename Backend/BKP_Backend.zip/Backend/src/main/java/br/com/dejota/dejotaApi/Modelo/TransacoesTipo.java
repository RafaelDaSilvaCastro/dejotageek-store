package br.com.dejota.dejotaApi.Modelo;

public enum TransacoesTipo {
    COMPRA,VENDA
}
