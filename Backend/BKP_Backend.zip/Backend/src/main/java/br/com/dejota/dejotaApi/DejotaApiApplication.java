package br.com.dejota.dejotaApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DejotaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DejotaApiApplication.class, args);
	}

}
